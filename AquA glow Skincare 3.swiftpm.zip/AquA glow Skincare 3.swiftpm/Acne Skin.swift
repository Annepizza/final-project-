import SwiftUI
struct AcneView: View {
    let place =
    URL(string:"https://www.google.com/maps/place/Sal+and+Tony's+Italian/@42.1522118,-87.9701776,16.34z/data=!4m6!3m5!1s0x880fbda9ac884ba5:0xdd9237a6d36f747f!8m2!3d42.153121!4d-87.9684334!16s%2Fg%2F11mxbll0zq?entry=ttu")!
    
    var body: some View {
        Text("Acne Skin")
            .font(.largeTitle)
        Divider()
        
        Text("If you're here, you might have Ance issues. If you have any of these problems. You clicked the right link!")
        .foregroundColor(.purple)
        
        Divider()
        Text("-Skin has a lot of pimples.")
            .frame(width: 830, height: 15, alignment: .topLeading)
        .foregroundColor(.blue)
        Text("-pimples are not going away or multiplying")
            .frame(width: 830, height: 15, alignment: .topLeading)
        Text("-can't put make up on due to it looking bumpy.")
            .frame(width: 830, height: 15, alignment: .topLeading)
        .foregroundColor(.blue)
        Text("-a bunch of pimples in one spot or spread all over you face.")
            .frame(width: 830, height: 15, alignment: .topLeading)
        Text("-Skin/pimples hurts to touch or giving you headaces.")
            .frame(width: 830, height: 15, alignment: .topLeading)
        .foregroundColor(.blue)
        Text("-uncomfortable looking at or redness over your face looking like a rash.")
            .frame(width: 830, height: 15, alignment: .topLeading)
        Divider()
        
    }
}



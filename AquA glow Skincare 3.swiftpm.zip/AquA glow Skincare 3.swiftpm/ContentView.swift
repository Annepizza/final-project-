import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView{
            VStack {
                Text("Welcome to AquA Glow Skincare")
                    .font(.title2)
                Divider()
                
               Text("If your skin is dry and pealing and you cant even put on makeup... Click the link below!")
                    .foregroundColor(.purple)
               
                NavigationLink(destination: DrySkinView()){
                    Text("Products For Skin With Dry Skin")
                        .padding(5)
                        .border(Color.black, width: 3)
                        .cornerRadius(5)
                } 
                Divider()
                
                Text("If your skin has a lot of pimples/Texture and make up is werid looking... Click the link below!")
               .foregroundColor(.purple)
                NavigationLink(destination: AcneView()){
                    Text("Products For Skin With Acne")
                        .padding(5)
                        .border(Color.black, width: 3)
                        .cornerRadius(5)
                }
                
                Divider()
                
                Text("If the Dry Skin products arent working, it could be the what you eat... Click the link below to see what foods are good!")
                .foregroundColor(.purple)
                NavigationLink(destination: DrySkinFood()){
                    Text("Foods That Can Cause Dry Skin")
                        .padding(5)
                        .border(Color.black, width: 3)
                        .cornerRadius(5)
                }
               
                    Divider()
                
                Text("If the Acne products arent working, it could be what you eat... Click the link below to see what foods are good!")
                .foregroundColor(.purple)
                NavigationLink(destination: AcneSkinFoods()){
                    Text("Foods That Can Cause Acne")
                        .padding(5)
                        .border(Color.black, width: 3)
                     .cornerRadius(5)
                }
                
                Divider()
                Spacer()
                Divider()
                Text("This app was created by Anne Lionello and Alla Kokotko.")
                .foregroundColor(.red)
                    .font(.footnote)
            }
        }
    }
}

import SwiftUI
struct DrySkinFood: View {
    let place =
    URL(string:"https://www.google.com/maps/place/Sal+and+Tony's+Italian/@42.1522118,-87.9701776,16.34z/data=!4m6!3m5!1s0x880fbda9ac884ba5:0xdd9237a6d36f747f!8m2!3d42.153121!4d-87.9684334!16s%2Fg%2F11mxbll0zq?entry=ttu")!
    
    var body: some View {
        Text("Foods For Dry Skin")
            .font(.largeTitle)
        Divider()
        
        Text("Curtain foods can cause dry skin. its like how people say carrots are good for you eyes, Curtain foods are good to eat for your skin.")
        Divider()
    }
}



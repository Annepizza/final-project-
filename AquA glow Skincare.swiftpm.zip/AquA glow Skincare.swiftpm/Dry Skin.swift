import SwiftUI
struct DrySkinView: View {
    let place =
    URL(string:"https://www.google.com/maps/place/Sal+and+Tony's+Italian/@42.1522118,-87.9701776,16.34z/data=!4m6!3m5!1s0x880fbda9ac884ba5:0xdd9237a6d36f747f!8m2!3d42.153121!4d-87.9684334!16s%2Fg%2F11mxbll0zq?entry=ttu")!
    
    var body: some View {
    Text("Dry Skin")
        .font(.largeTitle)
        Divider()
            
        Text("if you clicked her you probably have issues with dry skin. If you have one of these problems bellow you click the right link")
            .foregroundColor(.purple)
        Divider()
        VStack{
            Text("-Skin looks dry/peeling")
            .frame(width: 830, height: 15, alignment: .topLeading)
            .foregroundColor(.blue)
             Text("-can't put make up on due to it peeling off")
            .frame(width: 830, height: 15, alignment: .topLeading)
             Text("-Rubbing lotion on, but it just peels right off.")
            .frame(width: 830, height: 15, alignment: .topLeading)
            .foregroundColor(.blue)
             Text("-skin hurts")
            .frame(width: 830, height: 15, alignment: .topLeading)
             Text("-uncomfortable dryness")
                .frame(width: 830, height: 15, alignment: .topLeading)
            .foregroundColor(.blue)
            Text("-Dry area that looks or turns into a rash")
                .frame(width: 830, height: 15, alignment: .topLeading)
            Divider()
            
        }
        
    }
}


